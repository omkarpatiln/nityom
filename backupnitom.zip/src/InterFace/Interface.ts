interface PROFILE_DATA {
  NAME: string;
  EMAIL: String;
  MOBILE_NUMBER: string;
  PASSWORD: string;
}

export type {PROFILE_DATA};
