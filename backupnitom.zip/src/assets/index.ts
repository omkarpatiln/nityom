const no_data = require('./images/no_data.jpeg');
const noProfile = require('./images/noProfile.png');
const Logo = require('./images/Logo.jpg');

export {no_data, noProfile, Logo};
