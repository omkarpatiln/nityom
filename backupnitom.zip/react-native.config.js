module.exports = {
  project: {
    ios: {},
    android: {},
  },
  assets: ['./assets/'],
  dependencies: {
    'react-native-vector-icons': {
      platforms: {
        ios: null,
      },
    },
  },
};
